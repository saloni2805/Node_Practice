var mysql = require('mysql2');
const connection = mysql.createConnection({

    user: 'root',
    host: 'localhost',
    database: 'node_js_10am_apr',
    password: '',
    port: 3307
})

// check connect or not

connection.connect((err)=>{

    if(err)
    {
        console.log(err)
        console.log("DB Connection Faild...")
        return;
    }

    else
    {
        console.log("DB Connection Successfully ....")
    }

})


module.exports=connection;