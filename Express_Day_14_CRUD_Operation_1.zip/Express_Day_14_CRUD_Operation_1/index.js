var express = require('express');
const app = express();


const PORT = 3000 || process.env.PORT;
const HOST = '127.0.0.1';


// static file serve
app.use(express.static('public/'));

var url = require('url');

// body
app.use(express.urlencoded({ extended: 'true' }));

// json data
app.use(express.json());


// import connection
var connection = require('./config/db')


app.get('/', (req, res) => {
    res.render('home.ejs')
})


app.post('/saveform', (req, res) => {

    // res.send("Form Successfully Submitted...")

    // Object Destructring
    const { empName, empEmail, pass, empRole } = req.body;


    var sql = `insert into employee(empName,empEmail,pass,empRole) values('${empName}','${empEmail}','${pass}','${empRole}')`
    const result = connection.query(sql, (err, result) => {
        if (err) {
            console.log(err)
            console.log("Data Faild to insert")
        }

        else {
            console.log(result)
            console.log("Data Inserted Successfully...")
        }
    })
    // console.log(result);


    // res.send(sql);


    // res.send(`

    //     <h2>Emp Name - ${empName}</h2>
    //     <h2>Emp EMail - ${empEmail}</h2>
    //     <h2>Emp Password - ${pass}</h2>
    //     <h2>Emp Role - ${empRole}</h2>

    //     `)


    res.redirect('/empdata')
})


app.get('/empdata', (req, res) => {

    var sql = `select * from employee`;
    connection.query(sql, (err, result) => {
        if (err) {
            console.log("Data Not fetched")
            console.log(err)
        }

        else {
            console.log("Data Fetched Successfully...")
            console.log(result)


            // Data Traversing
            const obj= { data: result }

            res.render('empdata.ejs',obj)

        }
    })


    // res.send(`<h1>EMp Data Here...</h1>`)
})

app.listen(PORT, HOST, () => {
    console.log(`Server Is running.....`);
})