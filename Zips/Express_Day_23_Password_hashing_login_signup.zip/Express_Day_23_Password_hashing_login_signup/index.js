var express = require('express')
const app = express()

// middlewares
app.use(express.static('public/'))

app.use(express.urlencoded({ extended: true }))
app.use(express.json());

// db
const conn = require('./config/db')

// multer
// const multer=require('multer')

// const storage=multer.diskStorage({
//     destination:'public/uploads/',
//     filename:(req,file,cb)=>{
//         cb(null,Date.now()+file.originalname);

//     }
// })
// const upload=multer({storage:storage})


// session
var session = require('express-session')
app.use(session({
    resave: true,
    saveUninitialized: true,
    secret: 'lhdfkdjfkdkadn'
}))


// password hashing
var bcrypt = require('bcryptjs');


app.get('/', (req, res) => {
    res.render('home.ejs')
})


// post
app.post('/saveform', async (req, res) => {
    // res.send(req.body)

    // var sql=`create table meta(meta_id INT PRIMARY KEY AUTO_INCREMENT,
    //  useremail VARCHAR(200), userpass VARCHAR(100), usermobile VARCHAR(20))`;

    const { useremail, userpass, usermobile } = req.body;

    const salt = await bcrypt.genSalt(10);
    const hashPassword = await bcrypt.hash(userpass, salt)


    var sql = `insert into meta (useremail,userpass,usermobile) values('${useremail}','${hashPassword}','${usermobile}')`
    // res.send(sql);
    await conn.execute(sql);


    // res.send("<h1>Account Created,...</h1>")
    res.redirect('/login')

})



app.get('/login', (req, res) => {
    res.render('login.ejs')
})

app.post('/loginuser', async (req, res) => {

    const { useremail, userpass } = req.body;
    // const isMatch = await bcrypt.compare(userpassword, results[0].userpassword);


    var sql = `select * from meta where useremail='${useremail}';`;
    const result = await conn.execute(sql);

    if (result[0].length == 0) {

        res.send(`<script>

            alert('User Not Found...')
            window.location.href='/'
            </script>`)

        return;
    }


    const isMatch = await bcrypt.compare(userpass, result[0][0].userpass)
    // console.log(isMatch)
    if (isMatch) {

        req.session.meta_id = result[0][0].meta_id;

        res.send(`<script>alert('Login Successfully')
            
            window.location.assign('/profile')
            </script>
            `)
        return;
    }

    else {
        res.send(`<script>
            
            alert('Invalid Password...')
            window.location.href='/login'
            </script>`)

        return;
    }



    // console.log(result[0])
    // res.send(req.body)
})

app.get('/profile', (req, res) => {

    if (req.session.meta_id) {
        res.send("<h1>Profile Page Open </h1>" + req.session.meta_id)

    }

    else {
        res.send(`<script>
        
            window.location.href='/login'
            
            </script>`)
    }
})


const PORT = 3000 || process.env.PORT;


app.listen(PORT, () => {
    console.log(`server is running on http://localhost:${PORT}`)
})