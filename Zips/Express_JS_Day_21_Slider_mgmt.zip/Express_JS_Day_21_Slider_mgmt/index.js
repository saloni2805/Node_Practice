var express = require('express')
const app = express()



// req.body
app.use(express.urlencoded({ extended: true }))

// statc file serve
app.use(express.static('public/'))

// file multer
var multer = require('multer')

const storage = multer.diskStorage({
    destination: 'public/uploads/',
    filename: (req, file, cb) => {
        cb(null, Date.now() + file.originalname);
    }
})


// db 
var connection = require('./config/db')

const upload = multer({ storage: storage })


app.get('/', async (req, res) => {

    try {
        var sql = `select * from slider limit 2`;
        const result = await connection.execute(sql);

        const obj={data:result[0]}

        res.render('home.ejs',obj)
    } catch (err) {
        console.log(err)
    }
})


app.get('/manage_slider', async (req, res) => {

    var sql = `select * from slider`;
    const result = await connection.execute(sql);
    console.log(result[0][0])

    const obj = { data: result[0] }
    res.render('manageslider.ejs', obj)
})

app.get('/add_slider', (req, res) => {
    res.render("add_slider.ejs")
})

// **********************************

app.post('/saveform', upload.single('file'), async (req, res) => {


    try {


        // res.send("<h1>Slider Added Successfully...</h1>")
        // res.send({
        //     data: req.body,
        //     file: req.file
        // })


        // create table slider(slider_id INT PRIMARY KEY AUTO_INCREMENT,  slider_title VARCHAR(200),slider_desc TEXT,file VARCHAR(200) )

        const { slider_title, slider_desc } = req.body;
        const file = req.file ? req.file.filename : null;


        var sql = `insert into slider(slider_title,slider_desc,file) values('${slider_title}','${slider_desc}','${file}')`;
        // res.send(sql)
        await connection.execute(sql);


        res.redirect('/manage_slider')
    } catch (err) {
        console.log(err)
    }


})

// 
app.get('/delete/:id', async (req, res) => {

    try {
        var id = req.params.id;
        var sql = `delete from slider where slider_id='${id}'`;
        await connection.execute(sql);


        res.redirect('/manage_slider')

    } catch (err) {
        console.log(err)
    }

})



const PORT = 3000 || process.env.PORT
const HOST = '127.0.0.1';

app.listen(PORT, HOST, () => {
    console.log(`Server Is Up on http://${HOST}:${PORT}`)
})