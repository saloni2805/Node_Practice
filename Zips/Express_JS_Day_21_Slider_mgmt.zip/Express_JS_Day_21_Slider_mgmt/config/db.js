
const mysql = require('mysql2/promise')
const pool = mysql.createPool({

    host: 'localhost',
    user: 'root',
    database: 'node_js_10am_apr',
    password: '',
    port: 3307

})



async function test() {
    try {
        const res = await pool.execute('select 1')
        console.log(res)
        console.log("DB Connection Successfull")

    } catch (err) {
        console.log(err)
    }

    
}
test()

// wait pool.query('SELECT 1'); // Just checks if DB responds
// This is the cleanest way to verify that your DB connection is live without touching your real data.

module.exports = pool