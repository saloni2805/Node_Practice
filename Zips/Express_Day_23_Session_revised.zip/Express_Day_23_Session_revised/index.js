const express = require('express')
const app = express()

const PORT = 3000;
const HOST = '127.0.0.1';



//static file serve
app.use(express.static('public/'))


// req.body
app.use(express.urlencoded({ extended: true }))

// db connection
var connection = require('./config/db')

// express-session config
var session = require('express-session')
app.use(session({
    resave: true,
    // Forces a session that is "uninitialized"
    //  to be saved to the store. A session is uninitialized when it is new but not modified. 
    saveUninitialized: true,
    secret: 'Pratik'
}))


app.get('/', (req, res) => {
    res.render('home.ejs')
})




app.post('/saveform', async (req, res) => {


    try {


        // var sql = `create table instagram (insta_id INT PRIMARY KEY AUTO_INCREMENT, 
        // useremail VARCHAR(200), 
        // userpass VARCHAR(200),
        // usermobile VARCHAR(20));`


        const { useremail, userpass, usermobile } = req.body;

        var sql = `insert into instagram(useremail,userpass,usermobile) values('${useremail}','${userpass}','${usermobile}')`
        await connection.execute(sql);

        // res.send("<h1>Accoutnt Created SUccessfully</h1>")

        res.redirect('/login')


    } catch (err) {
        console.log(err)
        console.log("Faild to insert data")
    }


})


app.get('/login', (req, res) => {
    res.render('login.ejs')
})



app.post('/loginuser', async (req, res) => {
    // res.send("<h1>Login Successfully..</h1>")

    const { useremail, userpass } = req.body;

    var sql = `select * from instagram where useremail='${useremail}' And userpass='${userpass}'`;
    const result = await connection.execute(sql)

    if (result[0].length > 0) {
        // res.send(`<h1>Login Successfully...</h1>`)

        // After login process we get to knoe user
        //  is valid so after that stored insta id to the session for future used - /profie /messages /notification

        req.session.insta_id = result[0][0].insta_id;
        req.session.useremail = result[0][0].useremail;

        // res.send(result[0][0])
        // res.send("<h1>Login Successfully</h1>"+req.session.insta_id+req.session.useremail)
        res.redirect('/profile')

    }


    else {
        // res.send("<h1>Login faild - Invalid Credentials....</h1>")

        res.send(`
            
            <script>

            alert('Invalid Credentials - Login faild');
            // window.location.href='/login'
            window.location.assign('/login');

            </script>
            `)
    }


    // res.send(result[0])
})



// *****************************************


// After Login

app.get('/profile', (req, res) => {

    if (req.session.insta_id) {
        // res.send("<h1>Profile Page Open</h1>" + req.session.insta_id)

        const obj = { useremail: req.session.useremail }
        res.render('profile.ejs',obj)
    }
    else {
        // res.redirect('/login')

        res.send(`
            <script>alert('Login To Open Profile')            
            window.location.href='/login'
            </script>
            `)
    }

})

app.get('/notification', (req, res) => {

    if (req.session.insta_id) {
        res.send("<h1>Notification Page Open</h1>")
    }

    else {
        res.redirect('/login')
    }
})

app.get('/messages', (req, res) => {

    if (req.session.insta_id) {
        res.send("<h1>Messages Page Open</h1>")


    }
    else {
        res.redirect('/login')
    }
})






// *****************************************






app.listen(PORT, HOST, () => {
    console.log("Server is Up")
})


// instagram

// insta_id
// useremail
// userpass
// usermobile

// create table instagram (insta_id INT PRIMARY KEY AUTO_INCREMENT, useremail VARCHAR(200), userpass VARCHAR(200),usermobile VARCHAR(20));

